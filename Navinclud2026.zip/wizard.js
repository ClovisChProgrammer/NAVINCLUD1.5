const PLATES = [
  { id: 1, img: 'plate1.webp', options: [12, 15, 17, 'Nada'], correct: 12, type: 'control' },
  { id: 2, img: 'plate2.webp', options: [8, 3, 5, 'Nada'], correct: 8, type: 'deutan' },
  { id: 3, img: 'plate3.webp', options: [29, 70, 21, 'Nada'], correct: 29, type: 'protan' },
  { id: 4, img: 'plate4.webp', options: [5, 2, 6, 'Nada'], correct: 5, type: 'deutan' },
  { id: 5, img: 'plate5.webp', options: [45, 15, 10, 'Nada'], correct: 45, type: 'protan' },
  { id: 6, img: 'plate6.webp', options: [12, 1, 6, 'Nada'], correct: 6, type: 'tritan' },
  { id: 7, img: 'plate7.webp', options: [7, 4, 1, 'Nada'], correct: 7, type: 'achroma' },
  { id: 8, img: 'plate8.webp', options: [16, 13, 10, 'Nada'], correct: 16, type: 'achroma' },
  { id: 9, img: 'plate9.webp', options: [73, 13, 8, 'Nada'], correct: 73, type: 'control' }
];

// Adicionada categoria 'control' ao score
let currentStep = 0;
let scores = { deutan: 0, protan: 0, tritan: 0, achroma: 0, control: 0 };

document.addEventListener('DOMContentLoaded', () => {
  const setupStart = document.getElementById('setup-start');
  const quizContainer = document.getElementById('quiz-container');
  const resultsScreen = document.getElementById('results-screen');
  const startBtn = document.getElementById('start-btn');
  const plateImg = document.getElementById('plate-display');
  const optionsContainer = document.getElementById('options-container');
  const progressFill = document.getElementById('progress');

  if (startBtn) {
    startBtn.addEventListener('click', () => {
      setupStart.classList.remove('active');
      quizContainer.classList.add('active');
      renderStep();
    });
  }

  function renderStep() {
    if (currentStep >= PLATES.length) {
      showResults();
      return;
    }

    const plate = PLATES[currentStep];
    plateImg.src = `images/${plate.img}`;
    optionsContainer.innerHTML = '';

    plate.options.forEach(opt => {
      const btn = document.createElement('button');
      btn.className = 'option-btn';
      btn.textContent = opt;
      btn.addEventListener('click', () => handleChoice(opt));
      optionsContainer.appendChild(btn);
    });

    progressFill.style.width = `${((currentStep + 1) / PLATES.length) * 100}%`;
  }

  function handleChoice(choice) {
    const plate = PLATES[currentStep];
    const isCorrect = String(choice).trim() === String(plate.correct).trim();
    
    if (!isCorrect) {
      // Agora pontua TUDO, inclusive controle
      scores[plate.type]++;
      console.log(`Erro em: ${plate.type}. Score:`, scores);
    }
    
    currentStep++;
    renderStep();
  }

  function showResults() {
    quizContainer.classList.remove('active');
    resultsScreen.classList.add('active');

    // Inicializa como Visão Padrão
    let suggestion = { type: 'none', intensity: 100, shift: 0.5 };
    let diag = "Visão Padrão";
    let desc = "Sua percepção cromática parece estar dentro dos níveis de normalidade.";

    // Cálculo de Erros Totais (exceto controle para a soma de daltonismo)
    const daltonismErrors = scores.deutan + scores.protan + scores.tritan + scores.achroma;
    const totalErrors = daltonismErrors + scores.control;

    if (totalErrors > 0) {
      // 1. Se errou o CONTROLE: Indica falha severa ou má calibração do monitor
      if (scores.control > 0 && daltonismErrors === 0) {
        suggestion = { type: 'custom', intensity: 130, shift: 0.7 };
        diag = "Baixa Sensibilidade Detectada";
        desc = "Você teve dificuldade em placas de controle. Sugerimos um filtro de alto contraste.";
      }
      // 2. Acromatopsia (Forte indício)
      else if (scores.achroma >= 2) {
        suggestion = { type: 'achromatopsia', intensity: 100, shift: 0.5 };
        diag = "Acromatopsia Detectada";
        desc = "Forte indicação de ausência de percepção de cores.";
      }
      // 3. Analisar qual categoria de daltonismo venceu
      else {
        // Encontra a categoria com mais erros entre as de daltonismo
        const winner = Object.keys(scores).reduce((a, b) => {
          if (b === 'control') return a; // Ignora controle na disputa de "tipo"
          return scores[a] >= scores[b] ? a : b;
        });

        const configMap = {
          deutan: { type: 'deuteranopia', diag: 'Deuteranopia (Verde)', intensity: 125, shift: 0.65 },
          protan: { type: 'protanopia', diag: 'Protanopia (Vermelho)', intensity: 125, shift: 0.65 },
          tritan: { type: 'tritanopia', diag: 'Tritanopia (Azul)', intensity: 115, shift: 0.5 },
          achroma: { type: 'achromatopsia', diag: 'Acromatopsia Parcial', intensity: 100, shift: 0.5 }
        };

        const res = configMap[winner];
        suggestion = { type: res.type, intensity: res.intensity, shift: res.shift };
        diag = res.diag;
        desc = `Identificamos indícios de ${diag}.`;
      }
    }

    const resultBox = document.getElementById('result-text');
    resultBox.innerHTML = `
      <p style="font-size: 16px; margin-bottom: 8px;"><strong>${diag}</strong></p>
      <p style="font-size: 12px; color: #444; margin-bottom: 12px;">${desc}</p>
      <div style="font-size: 11px; border-top: 1px solid #ddd; padding-top: 10px; color: #666;">
        Configuração recomendada: <span style="color:var(--ni-accent); font-weight:bold;">${suggestion.type.toUpperCase()}</span> 
        com <span style="font-weight:bold;">${suggestion.intensity}%</span> de intensidade.
      </div>
    `;

    document.getElementById('apply-wizard').onclick = () => {
      const finalSettings = { ...suggestion, enabled: (suggestion.type !== 'none'), fixar: true };
      
      chrome.storage.local.set({ navIncludSettings: finalSettings }, () => {
        chrome.tabs.query({}, (tabs) => {
          tabs.forEach(tab => {
            if (tab.id && tab.url?.startsWith('http')) {
              chrome.tabs.sendMessage(tab.id, { 
                action: 'applyNavInclud', 
                settings: finalSettings, 
                source: 'message' 
              }).catch(() => {});
            }
          });
        });
        window.close();
      });
    };
  }

  document.getElementById('close-wizard').onclick = () => window.close();
});