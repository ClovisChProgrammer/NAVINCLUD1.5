// 1. EVENTO DE INSTALAÇÃO (Setup Inicial)
// Garante que, ao instalar, o objeto de configurações já exista no Storage
chrome.runtime.onInstalled.addListener(() => {
  console.log("NAVINCLUD: Sistema Iniciado com Sucesso.");
  chrome.storage.local.get(['navIncludSettings'], (res) => {
    if (!res.navIncludSettings) {
      const defaultSettings = {
        enabled: false,
        type: 'none',
        intensity: 100,
        shift: 0.5,
        fixar: true
      };
      chrome.storage.local.set({ navIncludSettings: defaultSettings });
    }
  });
});

// 2. MONITOR DE NAVEGAÇÃO
// Toda vez que o usuário muda de página ou atualiza, o background "reforça" o filtro
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  // Verificamos se a página terminou de carregar e se é uma URL válida (http/https)
  if (changeInfo.status === 'complete' && tab.url && tab.url.startsWith('http')) {
    
    chrome.storage.local.get(['navIncludSettings'], (res) => {
      const settings = res.navIncludSettings;
      
      if (settings && settings.enabled) {
        // Tentamos enviar a mensagem para o content.js da aba
        chrome.tabs.sendMessage(tabId, { 
          action: 'applyNavInclud', 
          settings: settings 
        }).catch((err) => {
          // Se der erro, é porque o content.js ainda não injetou. 
          // O próprio content.js lerá do storage ao carregar, então ignoramos.
          console.log("NAVINCLUD: Aguardando injeção do script na aba", tabId);
        });
      }
    });
  }
});

// 3. PERSISTÊNCIA DE MENSAGENS (Opcional para debugging)
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "ping") {
    sendResponse({ status: "alive" });
  }
});