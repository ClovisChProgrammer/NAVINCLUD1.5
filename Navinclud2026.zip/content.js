// Função principal que aplica o filtro via CSS e SVG
function applyNavIncludFilter(settings) {
  // Remove filtro anterior se existir
  const oldStyle = document.getElementById('navinclud-style');
  if (oldStyle) oldStyle.remove();
  const oldSVG = document.getElementById('navinclud-svg');
  if (oldSVG) oldSVG.remove();

  if (!settings || !settings.enabled || settings.type === 'none') {
    document.documentElement.style.filter = '';
    return;
  }

  // Criar o filtro SVG dinâmico (Engenharia de Daltonismo)
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.id = "navinclud-svg";
  svg.style.display = "none";
  
  const matrix = getMatrix(settings.type, settings.intensity / 100);
  
  svg.innerHTML = `
    <defs>
      <filter id="navinclud-filter">
        <feColorMatrix type="matrix" values="${matrix}" />
      </filter>
    </defs>
  `;
  document.body.appendChild(svg);

  // Aplicar via CSS no elemento raiz
  const style = document.createElement('style');
  style.id = 'navinclud-style';
  style.innerHTML = `
    html {
      filter: url(#navinclud-filter) !important;
      transition: filter 0.3s ease;
    }
  `;
  document.head.appendChild(style);
}

// Matrizes de Daltonismo (CIE)
function getMatrix(type, intensity) {
  const m = {
    protanopia: "0.567, 0.433, 0, 0, 0, 0.558, 0.442, 0, 0, 0, 0, 0.242, 0.758, 0, 0, 0, 0, 0, 1, 0",
    deuteranopia: "0.625, 0.375, 0, 0, 0, 0.7, 0.3, 0, 0, 0, 0, 0.3, 0.7, 0, 0, 0, 0, 0, 1, 0",
    tritanopia: "0.95, 0.05, 0, 0, 0, 0, 0.433, 0.567, 0, 0, 0, 0.475, 0.525, 0, 0, 0, 0, 0, 1, 0",
    achromatopsia: "0.299, 0.587, 0.114, 0, 0, 0.299, 0.587, 0.114, 0, 0, 0.299, 0.587, 0.114, 0, 0, 0, 0, 0, 1, 0",
    custom: "1.2, 0, 0, 0, 0, 0, 1.2, 0, 0, 0, 0, 0, 1.2, 0, 0, 0, 0, 0, 1, 0"
  };
  return m[type] || m.custom;
}

// 1. Ouvir mensagens do Popup ou Wizard
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'applyNavInclud') {
    applyNavIncludFilter(message.settings);
  }
});

// 2. Ler do Storage ao carregar a página (Garante persistência)
chrome.storage.local.get(['navIncludSettings'], (res) => {
  if (res.navIncludSettings && res.navIncludSettings.enabled) {
    // Pequeno delay para garantir que o body já exista
    setTimeout(() => applyNavIncludFilter(res.navIncludSettings), 100);
  }
});