document.addEventListener('DOMContentLoaded', () => {
  const elements = {
    type: document.getElementById('daltonismType'),
    intensity: document.getElementById('intensitySlider'),
    shift: document.getElementById('shiftSlider'),
    fixar: document.getElementById('toggleFixar'),
    enabled: document.getElementById('toggleFilter'),
    applyBtn: document.getElementById('applyBtn'),
    resetBtn: document.getElementById('resetBtn'),
    intensityVal: document.getElementById('intensityValue'),
    shiftVal: document.getElementById('shiftValue'),
    dragHandle: document.querySelector('.drag-handle'),
    openWizard: document.getElementById('openWizard')
  };

  const parseIntensity = (raw) => {
    const n = parseInt(raw, 10);
    if (!Number.isFinite(n)) return 100;
    return Math.min(150, Math.max(0, n));
  };

  const sliderToShift = (sliderVal) => {
    const n = Number(sliderVal);
    if (!Number.isFinite(n)) return 0.5;
    return Math.min(1, Math.max(0, n / 100));
  };

  const shiftToSlider = (shift) => {
    if (typeof shift === 'number' && Number.isFinite(shift)) {
      return Math.round(Math.min(1, Math.max(0, shift)) * 100);
    }
    return 50;
  };

  const updateLabels = () => {
    elements.intensityVal.textContent = `${elements.intensity.value}%`;
    elements.shiftVal.textContent = sliderToShift(elements.shift.value).toFixed(2);
  };

  const readSettingsFromUi = () => ({
    type: elements.type.value || 'none',
    intensity: parseIntensity(elements.intensity.value),
    shift: sliderToShift(elements.shift.value),
    fixar: elements.fixar.checked,
    enabled: elements.enabled.checked
  });

  const broadcastApply = (settings) => {
    chrome.tabs.query({}, (tabs) => {
      for (const tab of tabs) {
        if (!tab.id || !tab.url || !/^https?:\/\//i.test(tab.url)) continue;
        chrome.tabs.sendMessage(tab.id, { action: 'applyNavInclud', settings, source: 'message' }).catch(() => {});
      }
    });
  };

  const sendSettings = () => {
    const newSettings = readSettingsFromUi();
    chrome.storage.local.get(['navIncludSettings'], (res) => {
      if (res.navIncludSettings) chrome.storage.local.set({ navIncludSettings_BACKUP: res.navIncludSettings });
      chrome.storage.local.set({ navIncludSettings: newSettings }, () => broadcastApply(newSettings));
    });
  };

  const applyToUi = (s) => {
    if (!s) return;
    elements.type.value = s.type || 'none';
    elements.intensity.value = s.intensity ?? 100;
    elements.shift.value = shiftToSlider(s.shift);
    elements.fixar.checked = s.fixar !== false;
    elements.enabled.checked = s.enabled !== false;
    updateLabels();
  };

  chrome.storage.local.get(['navIncludSettings'], (res) => {
    if (res.navIncludSettings) applyToUi(res.navIncludSettings);
  });

  // Event Listeners
  elements.type.addEventListener('change', sendSettings);
  elements.fixar.addEventListener('change', sendSettings);
  elements.enabled.addEventListener('change', sendSettings);
  elements.intensity.addEventListener('input', () => { updateLabels(); sendSettings(); });
  elements.shift.addEventListener('input', () => { updateLabels(); sendSettings(); });
  elements.applyBtn.addEventListener('click', sendSettings);

  elements.resetBtn.addEventListener('click', () => {
    chrome.storage.local.get(['navIncludSettings_BACKUP'], (res) => {
      const target = res.navIncludSettings_BACKUP || { type: 'none', intensity: 100, shift: 0.5, fixar: true, enabled: true };
      applyToUi(target);
      chrome.storage.local.set({ navIncludSettings: target }, () => broadcastApply(target));
    });
  });

  // Abrir Assistente
  elements.openWizard.onclick = (e) => {
    e.preventDefault();
    chrome.windows.create({
      url: chrome.runtime.getURL('wizard.html'),
      type: 'popup',
      width: 420,
      height: 600
    });
  };

  // Drag Window Logic
  if (elements.dragHandle && chrome.windows?.getCurrent) {
    elements.dragHandle.addEventListener('mousedown', (e) => {
      if (e.button !== 0 || e.target.closest('a,button,input,select')) return;
      chrome.windows.getCurrent((win) => {
        const ox = e.screenX, oy = e.screenY;
        const bl = win.left, bt = win.top;
        const onMove = (ev) => chrome.windows.update(win.id, { left: bl + (ev.screenX - ox), top: bt + (ev.screenY - oy) });
        const onUp = () => { window.removeEventListener('mousemove', onMove); window.removeEventListener('mouseup', onUp); };
        window.addEventListener('mousemove', onMove);
        window.addEventListener('mouseup', onUp);
      });
    });
  }
});